export const environment = {
    production: false,
    apiUrl: 'http://localhost:8888/api', // Change this as needed
  };
  